/* Libraries */

displayIdAndCurrentPriority()
{
  TaskType id;
  GetTaskID(&id);
  if (id >= 0)
  {
    tpl_priority prio = (tpl_dyn_proc_table[id]->priority) >> PRIORITY_SHIFT;
		lcd.print("Id=");
    lcd.print(id);
		lcd.print(", Prio=");
    lcd.print(prio);
  }
}
